    var filechoosed1;
    var ed,flag=0;
    var encrypted1;
    function canvasArrToString(a)
    {
        var s="";
        // Removes alpha to save space.
        for (var i=0; i<filechoosed1.length; i+=4)
        {
            s+=(String.fromCharCode(filechoosed1[i])
                + String.fromCharCode(filechoosed1[i+1])
                + String.fromCharCode(filechoosed1[i+2]));
        }
        return s;
    }
    function canvasStringToArr(s)
    {
        var arr=[];
        for (var i=0; i<s.length; i+=3)
        {
            for (var j=0; j<3; j++)
            {
                arr.push(s.substring(i+j,i+j+1).charCodeAt());
            }
            arr.push(255); // Hardcodes alpha to 255.
        }
        return arr;
    }
    function encryptAES()
    {
        var password = document.getElementById('ip2').value;
        var s= canvasArrToString(filechoosed1);
        var encrypted = Krypto.AES.encrypt(s, password);
        encrypted1=encrypted;
        document.getElementById("im1").setAttribute('src',encrypted);
        document.getElementById("im1").hidden=true;
        document.getElementById("lbl1").hidden=false;
        document.getElementById("lbl1").innerHTML="ENCRYPTED";
        document.getElementById("lbl3").hidden=true;
        flag=1;
    }
    function decryptAES()
    {
        var password = document.getElementById('ip2').value;
        var arr=canvasStringToArr(Krypto.AES.decrypt(encrypted1, password));
        for (var i=0; i<arr.length; i++)
        {
            arr[i]-=0; 
        }
        document.getElementById("im1").setAttribute('src',filechoosed1);
        document.getElementById("im1").hidden=false;
        document.getElementById("lbl1").hidden=true;
        document.getElementById("lbl3").hidden=false;
        flag=2;
    }
    function input()
    {
        document.getElementById("ip").click();
    }
    function choose()
    {
        document.getElementById("div2").style.background="rgb(239,222,205)";
        document.getElementById("lbl1").hidden=true;
        document.getElementById("lbl2").hidden=true;
        document.getElementById("ip2").hidden=false;
        document.getElementById("btn1").hidden=false;
        document.getElementById("btn2").hidden=false;
        document.getElementById("btn3").hidden=false;
        var filechoosed=document.getElementById("ip").files;
        var filereader=new FileReader();
        filereader.onload=function()
        {
            var result=filereader.result;
            filechoosed1=result;
            var img=document.getElementById("im1");
            img.setAttribute('src',result);
            img.hidden=false;
            console.log(result);
        }
        filereader.readAsDataURL(filechoosed[0]);
    }
    function download() 
    {
        //var imgpath=document.getElementById("im1").getAttribute('src');
        //var filenm=imgpath.substring(imgpath.lastIndexOf('/')+1);
        if (flag==0)
        {
            var imgpath=document.getElementById("im1").getAttribute('src');
            saveAs(imgpath,"sample.png");
        }
        else if (flag==1)
        {
            var blob=new Blob([encrypted1],{type: "image/jpg"});
            saveAs(blob,"encrepted.png");
        }
        else
        {
            var imgpath=document.getElementById("im1").getAttribute('src');
            saveAs(imgpath,"decrepted.png");
        }  
    }
    function enable()
    {
        var input=document.getElementById("ip2").innerHTML;
        if(input.trim!="")
        document.getElementById("btn2").disabled=false;
        document.getElementById("btn3").disabled=false;
    }